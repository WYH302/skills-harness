SkillHarbor portable Agent Skills. Review each SKILL.md before installation. Source transcripts are not included.
